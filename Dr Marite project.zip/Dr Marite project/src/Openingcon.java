
public class Openingcon {
      public static void main(String[] args){
        Home in=new Home();
          Opening s=new Opening();
          s.setVisible(true);
        try{
            for(int i=0;i<=100;i++){
                Thread.sleep(40);
                 s.LogNum.setText(Integer.toString(i)+"%");
                s.LogBar.setValue(i);
               
                if(i==100){
               in.setVisible(true);
               s.dispose();
                }
                   
                }
        }
        catch(Exception e){
        }
    }
}
