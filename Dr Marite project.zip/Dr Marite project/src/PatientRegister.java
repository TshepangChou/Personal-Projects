
import java.awt.event.KeyEvent;
  import java.sql.*;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Vector;

public class PatientRegister extends javax.swing.JFrame {
 private static final String UName = "root";
   private static final String Pass = "Zanele@14";
   private static final String Host = "jdbc:mysql://localhost:3306/patients";
   
   Connection sqlconn = null;
   PreparedStatement pst =null;
   ResultSet rs = null;
    public PatientRegister() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        FName = new javax.swing.JTextField();
        LName = new javax.swing.JTextField();
        Email = new javax.swing.JTextField();
        Age = new javax.swing.JTextField();
        IDNO = new javax.swing.JTextField();
        Physical = new javax.swing.JTextField();
        Phone = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        Gender = new javax.swing.JComboBox<>();
        Financial = new javax.swing.JComboBox<>();
        Marital = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        ID = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        lable2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Stencil", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 0, 0));
        jLabel1.setText("          Register patient");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-30, 80, 830, 60));

        FName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(FName, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 340, 130, 30));

        LName.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(LName, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 420, 130, 30));

        Email.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(Email, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 420, 130, 30));

        Age.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(Age, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 260, 130, 30));

        IDNO.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        IDNO.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                IDNOKeyPressed(evt);
            }
        });
        jPanel1.add(IDNO, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 490, 130, 30));

        Physical.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(Physical, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 340, 130, 30));

        Phone.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        Phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                PhoneActionPerformed(evt);
            }
        });
        Phone.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                PhoneKeyPressed(evt);
            }
        });
        jPanel1.add(Phone, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 260, 130, 30));

        jLabel4.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel4.setText("FIRST NAME");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 310, 110, -1));

        jLabel5.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel5.setText("LAST NAME");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 400, 110, -1));

        jLabel6.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel6.setText("ID N.O");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 470, 110, -1));

        jLabel7.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel7.setText("EMAIL ADRESS");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 400, 140, -1));

        jLabel8.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel8.setText("PHONE N.O");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 240, 110, -1));

        jLabel9.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel9.setText("MARITAL STATUS");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 470, 160, -1));

        jLabel10.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel10.setText("PHYSICAL ADRESS");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 310, 170, -1));

        jButton1.setFont(new java.awt.Font("Elephant", 1, 18)); // NOI18N
        jButton1.setForeground(new java.awt.Color(204, 0, 0));
        jButton1.setText("REGISTER");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 560, 160, -1));

        jButton3.setFont(new java.awt.Font("Elephant", 1, 18)); // NOI18N
        jButton3.setForeground(new java.awt.Color(204, 0, 0));
        jButton3.setText("EXIT");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 560, 160, 30));

        Gender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Male", "Female", " " }));
        Gender.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(Gender, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 340, 130, 30));

        Financial.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Yes ", "No" }));
        Financial.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(Financial, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 420, 130, 30));

        Marital.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Single", "Married", "Divorsed" }));
        Marital.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        Marital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MaritalActionPerformed(evt);
            }
        });
        jPanel1.add(Marital, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 490, 130, 30));

        jLabel11.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel11.setText("MEDICAL AID?");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 400, 140, -1));

        jLabel12.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel12.setText("AGE");
        jPanel1.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 240, 140, -1));

        jLabel13.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel13.setText("GENDER");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 310, 140, -1));

        jLabel14.setFont(new java.awt.Font("Times", 0, 10)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(204, 0, 0));
        jLabel14.setText("OF YOUR ID N.O AS FILE N.O:");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 210, 170, 20));

        jLabel19.setFont(new java.awt.Font("Times", 0, 10)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(204, 0, 0));
        jLabel19.setText("PLEASE ENTER FIRST SIX DIGITS  ");
        jPanel1.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 200, 170, 20));

        jLabel21.setFont(new java.awt.Font("Times", 0, 10)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(204, 0, 0));
        jPanel1.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 300, 220, 20));

        ID.setToolTipText("");
        ID.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(204, 0, 0)));
        jPanel1.add(ID, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 260, 130, 30));

        jLabel22.setFont(new java.awt.Font("Elephant", 0, 14)); // NOI18N
        jLabel22.setText("FILE  N.O");
        jPanel1.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 240, 90, -1));
        jPanel1.add(lable2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 530, 180, 10));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 782, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 671, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
                 
     
                 
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            sqlconn = DriverManager.getConnection(Host,UName,Pass);
            pst = sqlconn.prepareStatement("insert into patients.data(File_ID, First_Name, Last_Name, ID_Number, Age, Gender, Marital_Status, Phone_Number, Email_Adress, Medical_Aid, Physical_Adress) values(?,?,?,?,?,?,?,?,?,?,?) ");
            pst.setInt(1, Integer.parseInt(ID.getText()));
            pst.setString(2, FName.getText());
            pst.setString(3, LName.getText());
            pst.setString(4, IDNO.getText());
            pst.setString(5, Age.getText());
            pst.setString(6, (String) Gender.getSelectedItem());
            pst.setString(7, (String) Marital.getSelectedItem());
            pst.setString(8, Phone.getText());
            pst.setString(9, Email.getText());
            pst.setString(10, (String) Financial.getSelectedItem());
            pst.setString(11, Physical.getText());
           
              pst.executeUpdate();
           
            JOptionPane.showMessageDialog(this, "Succesfully Registered");
             Home H = new Home();
            H.setVisible(true);
            this.dispose();
        
      
  
        }
        catch(ClassNotFoundException ex){
            java.util.logging.Logger.getLogger(PATIENTS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
      catch(SQLException ex){
    java.util.logging.Logger.getLogger(PATIENTS.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
}
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        Home h = new Home();
        h.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void MaritalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MaritalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MaritalActionPerformed

    private void IDNOKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_IDNOKeyPressed
        String Contact  = IDNO.getText();

        int length = Contact.length();

       

        char x = evt.getKeyChar();

       

        if(length == 13){

           

            if (evt.getKeyChar()>'0' && evt.getKeyChar()<='9'){

               

                if (length<13){

                    IDNO.setEditable(true);

                }

                else{

                    IDNO.setEditable(false);

                }

            }

                else

               {

                if(evt.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode()==KeyEvent.VK_DELETE){

                   IDNO.setEditable(true);

                   lable2.setText(null);

                }

                else

                {

                    IDNO.setEditable(false);

                }    

            }

         }

        else

            if(length<9){

                lable2.setText("13 digits required");

            }

        else{

                lable2.setText(null);

            }
    }//GEN-LAST:event_IDNOKeyPressed

    private void PhoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_PhoneActionPerformed
        
    }//GEN-LAST:event_PhoneActionPerformed

    private void PhoneKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_PhoneKeyPressed
       String Contact  = IDNO.getText();

        int length = Contact.length();

       

        char x = evt.getKeyChar();

       

        if(length == 10){

           

            if (evt.getKeyChar()>'0' && evt.getKeyChar()<='9'){

               

                if (length<13){

                    Phone.setEditable(true);

                }

                else{

                    Phone.setEditable(false);

                }

            }

                else

               {

                if(evt.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || evt.getExtendedKeyCode()==KeyEvent.VK_DELETE){

                   Phone.setEditable(true);

                   lable2.setText(null);

                }

                else

                {

                    Phone.setEditable(false);

                }    

            }

         }

        else

            if(length<9){

                lable2.setText("10 digits required");

            }

        else{

                Phone.setText(null);

            }
    }//GEN-LAST:event_PhoneKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PatientRegister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PatientRegister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PatientRegister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PatientRegister.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new PatientRegister().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Age;
    private javax.swing.JTextField Email;
    private javax.swing.JTextField FName;
    private javax.swing.JComboBox<String> Financial;
    private javax.swing.JComboBox<String> Gender;
    private javax.swing.JTextField ID;
    private javax.swing.JTextField IDNO;
    private javax.swing.JTextField LName;
    private javax.swing.JComboBox<String> Marital;
    private javax.swing.JTextField Phone;
    private javax.swing.JTextField Physical;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lable2;
    // End of variables declaration//GEN-END:variables
}
