package Tshepang;

public class PharmacyUtils 
{
    public static String billPath = "C:\\Users\\Student\\Documents\\Advanced Diploma\\Project";
    //public static String billPath = "E:\\";//"E:/";
    //public static String billPath = "E:\\";
}