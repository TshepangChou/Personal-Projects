package common;

import java.io.File;
import javax.swing.JOptionPane;
import Tshepang.PharmacyUtils;

public class openpdf 
{
    public static void openById(String Id)
    {
        try
        {
            if((new File(PharmacyUtils.billPath+Id+".pdf")).exists())
            {
                Process p = Runtime
                        .getRuntime()
                        .exec("rundll32 url.dll,FileProtocolHandler "+PharmacyUtils.billPath+""+Id+".pdf");
            }
            else
            {
                JOptionPane.showMessageDialog(null, "File does not exists!!");
            }
        }
        catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
        }
    }
}