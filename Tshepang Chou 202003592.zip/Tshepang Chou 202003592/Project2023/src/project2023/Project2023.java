package project2023;

public class Project2023 {

    public static void main(String[] args) {
        // TODO code application logic here
    }    
}